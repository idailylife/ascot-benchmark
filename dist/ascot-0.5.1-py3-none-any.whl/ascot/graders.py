"""Grading: LLM judge evaluates expectations and assigns scores."""

from __future__ import annotations

import json
import logging
import re
import shutil
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING

log = logging.getLogger(__name__)

from .models import CaseResult, Expectation, ExpectationResult, TestCase

if TYPE_CHECKING:
    from opencode_wrapper import AsyncOpenCodeClient, RunResult


# ---------------------------------------------------------------------------
# LLM Judge
# ---------------------------------------------------------------------------

# Judge gets full permissions inside its own workspace so it can write
# and run scripts to inspect binary files (xlsx, docx, images, etc.).
JUDGE_PERMISSION: dict[str, str] = {
    "*": "allow",
    "question": "deny",
    "external_directory": "deny",
    "doom_loop": "deny",
}


def _setup_judge_workspace(case_dir: Path) -> Path:
    """Create an isolated workspace for the judge with case artifacts."""
    judge_ws = Path(tempfile.mkdtemp(prefix="ascot_judge_"))

    # Copy output files
    ws_src = case_dir / "workspace"
    if ws_src.is_dir():
        shutil.copytree(ws_src, judge_ws / "output")

    # Copy events log
    events_src = case_dir / "events.jsonl"
    if events_src.exists():
        shutil.copy2(events_src, judge_ws / "events.jsonl")

    return judge_ws


def _list_workspace_files(ws: Path, max_files: int = 50) -> str:
    """List files in workspace (excluding .opencode/) for the judge prompt."""
    files: list[str] = []
    for item in sorted(ws.rglob("*")):
        if ".opencode" in item.parts:
            continue
        if item.is_file():
            rel = item.relative_to(ws)
            size = item.stat().st_size
            files.append(f"  {rel}  ({size} bytes)")
            if len(files) >= max_files:
                files.append(f"  ... and more files (truncated at {max_files})")
                break
    return "\n".join(files) if files else "  (no files)"


async def llm_judge(
    case_dir: Path,
    test_case: TestCase,
    client: "AsyncOpenCodeClient",
    grading_model: str | None = None,
) -> tuple[list[ExpectationResult], dict]:
    """Run an OpenCode session to judge output against all expectations.

    Reads events.jsonl and workspace/ from case_dir to provide the judge
    with the agent's full execution trace and output files.

    Returns (expectation_results, judge_stats) where judge_stats contains
    token usage, cost, and turns from the judge LLM session.
    """
    from opencode_wrapper import RunConfig

    empty_stats: dict = {"tokens": {}, "cost": 0.0, "turns": 0}

    judge_ws = _setup_judge_workspace(case_dir)
    try:
        file_listing = _list_workspace_files(judge_ws / "output") if (judge_ws / "output").is_dir() else "(no files)"

        # Build numbered expectations list
        exp_lines = []
        for i, exp in enumerate(test_case.expectations):
            exp_lines.append(f"{i + 1}. {exp.desc} ({exp.score} pts)")
        exp_list = "\n".join(exp_lines)

        sections = [
            "You are a grading judge. Evaluate whether the agent's output "
            "meets EACH of the following expectations.\n",
            f"## Expectations\n{exp_list}\n",
            "## Available Evidence\n"
            "- `events.jsonl`: The agent's complete execution log (JSON lines). "
            "Each line is an event showing the agent's reasoning, tool calls, "
            "and outputs. Read this file to understand what the agent did.\n"
            "- `output/`: Directory containing all files the agent produced. "
            "Inspect these files to verify the agent's work.\n",
        ]

        if file_listing.strip() and file_listing.strip() != "(no files)":
            sections.append(
                f"## Output Files (in output/ directory)\n{file_listing}\n"
            )

        sections.append(
            "Evaluate based on ALL available evidence: read events.jsonl to "
            "understand the agent's execution, and inspect files in output/ to "
            "verify results. For binary files (xlsx, docx, etc.), write and run "
            "Python scripts to parse and verify their contents.\n\n"
            "Reply with ONLY a JSON object in this exact format:\n"
            "```json\n"
            "{\n"
            '  "results": [\n'
            '    {"index": 0, "passed": true, "reasoning": "brief explanation"},\n'
            '    {"index": 1, "passed": false, "reasoning": "brief explanation"}\n'
            "  ]\n"
            "}\n"
            "```\n"
            "You MUST include exactly one entry per expectation, in order, using 0-based index."
        )

        prompt = "\n".join(sections)
        cfg = RunConfig(model=grading_model, permission=JUDGE_PERMISSION)
        result = await client.async_run(
            prompt, str(judge_ws), run_cfg=cfg, timeout_s=300,
        )
        text = _extract_text_from_result(result)
        judge_stats = _extract_stats(result)
        exp_results = _parse_judge_response(text, test_case.expectations)

        # Retry once if any expectation was missing from the response
        if any(er.reasoning == "Missing from judge response" for er in exp_results):
            missing = [er.desc for er in exp_results if er.reasoning == "Missing from judge response"]
            log.warning("Judge response missing expectations for case %s: %s — retrying",
                        test_case.id, missing)
            result = await client.async_run(
                prompt, str(judge_ws), run_cfg=cfg, timeout_s=300,
            )
            text = _extract_text_from_result(result)
            retry_stats = _extract_stats(result)
            exp_results = _parse_judge_response(text, test_case.expectations)
            # Merge stats: sum cost/turns, keep retry tokens
            judge_stats["cost"] = judge_stats.get("cost", 0.0) + retry_stats.get("cost", 0.0)
            judge_stats["turns"] = judge_stats.get("turns", 0) + retry_stats.get("turns", 0)
            judge_stats["tokens"] = retry_stats.get("tokens", judge_stats.get("tokens", {}))

        return exp_results, judge_stats
    except Exception as e:
        # On error, all expectations score 0
        return [
            ExpectationResult(
                desc=exp.desc, score=exp.score, earned=0,
                reasoning=f"Judge error: {e}",
            )
            for exp in test_case.expectations
        ], empty_stats
    finally:
        shutil.rmtree(judge_ws, ignore_errors=True)


def _parse_judge_response(
    text: str, expectations: list[Expectation],
) -> list[ExpectationResult]:
    """Parse judge response into per-expectation results."""
    # Try to find JSON with "results" array
    for match in re.finditer(r'\{[^{}]*"results"\s*:\s*\[.*?\]\s*\}', text, re.DOTALL):
        try:
            obj = json.loads(match.group())
            if "results" in obj and isinstance(obj["results"], list):
                return _map_results(obj["results"], expectations)
        except json.JSONDecodeError:
            continue

    # Fallback: try parsing the entire text as JSON
    try:
        obj = json.loads(text.strip())
        if isinstance(obj, dict) and "results" in obj:
            return _map_results(obj["results"], expectations)
    except (json.JSONDecodeError, ValueError):
        pass

    # Could not parse — all expectations fail
    return [
        ExpectationResult(
            desc=exp.desc, score=exp.score, earned=0,
            reasoning=f"Could not parse judge response: {text[:300]}",
        )
        for exp in expectations
    ]


def _map_results(
    raw_results: list[dict], expectations: list[Expectation],
) -> list[ExpectationResult]:
    """Map parsed JSON results to ExpectationResult objects by index."""
    # Build lookup by index
    by_index: dict[int, dict] = {}
    for item in raw_results:
        idx = item.get("index")
        if isinstance(idx, int):
            by_index[idx] = item

    results = []
    for i, exp in enumerate(expectations):
        item = by_index.get(i)
        if item is not None:
            passed = bool(item.get("passed", False))
            reasoning = item.get("reasoning", "")
            results.append(ExpectationResult(
                desc=exp.desc,
                score=exp.score,
                earned=exp.score if passed else 0,
                reasoning=reasoning,
            ))
        else:
            results.append(ExpectationResult(
                desc=exp.desc, score=exp.score, earned=0,
                reasoning="Missing from judge response",
            ))
    return results


def _extract_text_from_result(run_result: "RunResult") -> str:
    """Extract human-readable text from a RunResult."""
    from opencode_wrapper import run_result_fuzzy_text

    text = run_result.final_text.strip() if run_result.final_text else ""
    if text and not text.startswith('{"type":'):
        return text

    fuzzy = run_result_fuzzy_text(run_result).strip()
    if fuzzy and not fuzzy.startswith('{"type":'):
        return fuzzy

    pieces = []
    for ev in run_result.events:
        if ev.get("type") == "tool_use":
            part = ev.get("part", {})
            state = part.get("state", {})
            output = state.get("output", "")
            if isinstance(output, str) and output.strip():
                if not output.startswith("<") and len(output) < 2000:
                    pieces.append(output.strip())

    return "\n".join(pieces) if pieces else ""


def _extract_stats(run_result: "RunResult") -> dict:
    """Extract token usage, cost, and turns from a RunResult."""
    stats: dict = {"tokens": {}, "cost": 0.0, "turns": 0}
    if hasattr(run_result, "token_usage"):
        tu = run_result.token_usage
        stats["tokens"] = {
            "total": tu.total,
            "input": tu.input,
            "output": tu.output,
            "reasoning": tu.reasoning,
            "cache_read": tu.cache_read,
            "cache_write": tu.cache_write,
        }
    stats["cost"] = run_result.total_cost
    stats["turns"] = run_result.turns
    return stats


# ---------------------------------------------------------------------------
# Combined grading
# ---------------------------------------------------------------------------


async def grade_case(
    test_case: TestCase,
    case_dir: Path,
    run_result: "RunResult",
    duration: float,
    client: "AsyncOpenCodeClient",
    grading_model: str | None = None,
) -> tuple[CaseResult, dict]:
    """Grade a test case by running LLM judge on all expectations.

    Args:
        case_dir: Path to the case output directory containing events.jsonl
                  and workspace/.
        run_result: Used only for extracting agent token/cost stats.

    Returns (case_result, grading_stats) where grading_stats contains
    token usage, cost, and turns from the judge session.
    """
    expectation_results: list[ExpectationResult] = []
    score = 0
    max_score = 0
    grading_stats: dict = {"tokens": {}, "cost": 0.0, "turns": 0}

    if test_case.expectations:
        expectation_results, grading_stats = await llm_judge(
            case_dir, test_case, client, grading_model=grading_model,
        )
        score = sum(er.earned for er in expectation_results)
        max_score = sum(er.score for er in expectation_results)

    token_dict = {}
    if hasattr(run_result, "token_usage"):
        tu = run_result.token_usage
        token_dict = {
            "total": tu.total,
            "input": tu.input,
            "output": tu.output,
            "reasoning": tu.reasoning,
            "cache_read": tu.cache_read,
            "cache_write": tu.cache_write,
        }

    return CaseResult(
        case_id=test_case.id,
        score=score,
        max_score=max_score,
        expectation_results=expectation_results,
        final_text=_extract_text_from_result(run_result),
        exit_code=run_result.exit_code,
        token_usage=token_dict,
        total_cost=run_result.total_cost,
        turns=run_result.turns,
        duration_s=duration,
    ), grading_stats


def error_result(case_id: str, error: Exception, test_case: TestCase | None = None) -> CaseResult:
    """Create a failed CaseResult from an exception."""
    max_score = sum(e.score for e in test_case.expectations) if test_case else 0
    return CaseResult(
        case_id=case_id,
        score=0,
        max_score=max_score,
        error=f"{type(error).__name__}: {error}",
    )


# ---------------------------------------------------------------------------
# Review agent
# ---------------------------------------------------------------------------


def _setup_review_workspace(case_dir: Path, trial_results: list[CaseResult]) -> Path:
    """Create workspace for the review agent with all trial artifacts."""
    review_ws = Path(tempfile.mkdtemp(prefix="ascot_review_"))

    trial_dirs = sorted(case_dir.glob("trial-*"))
    for td in trial_dirs:
        trial_name = td.name  # e.g. "trial-1"
        dest = review_ws / trial_name

        # Copy events
        events_src = td / "events.jsonl"
        if events_src.exists():
            dest.mkdir(parents=True, exist_ok=True)
            shutil.copy2(events_src, dest / "events.jsonl")

        # Copy workspace output
        ws_src = td / "workspace"
        if ws_src.is_dir():
            shutil.copytree(ws_src, dest / "output")

    return review_ws


def _build_review_prompt(
    test_case: TestCase,
    trial_results: list[CaseResult],
) -> str:
    """Build the prompt for the review agent."""
    sections: list[str] = []

    sections.append(
        "You are a diagnostic reviewer analyzing why a benchmark test case "
        "failed. Do NOT re-grade. Your job is to identify root causes and "
        "patterns across trials.\n"
    )

    # Original task
    sections.append(f"## Original Task Prompt\n{test_case.prompt}\n")

    # Expectations
    exp_lines = []
    for i, exp in enumerate(test_case.expectations):
        exp_lines.append(f"{i + 1}. {exp.desc} ({exp.score} pts)")
    sections.append(f"## Expectations\n" + "\n".join(exp_lines) + "\n")

    # Per-trial results summary
    sections.append("## Trial Results\n")
    has_mixed = False
    any_pass = False
    any_fail = False
    for i, tr in enumerate(trial_results, 1):
        tag = "PASS" if tr.score == tr.max_score else "FAIL"
        if tr.score == tr.max_score:
            any_pass = True
        else:
            any_fail = True
        sections.append(f"### Trial {i}: [{tag}] {tr.score}/{tr.max_score}")
        if tr.error:
            sections.append(f"Error: {tr.error}")
        for er in tr.expectation_results:
            status = "PASS" if er.earned > 0 else "FAIL"
            line = f"- [{status}] {er.desc}"
            if er.reasoning:
                line += f" — {er.reasoning[:300]}"
            sections.append(line)
        sections.append("")

    has_mixed = any_pass and any_fail

    # Instructions
    sections.append("## Available Evidence\n")
    for i in range(1, len(trial_results) + 1):
        sections.append(
            f"- `trial-{i}/events.jsonl`: Agent execution log for trial {i}\n"
            f"- `trial-{i}/output/`: Files produced by the agent in trial {i}"
        )
    sections.append("")

    if has_mixed:
        sections.append(
            "IMPORTANT: Some trials passed and some failed. Compare the "
            "successful trial(s) against the failed one(s) to identify what "
            "the agent did differently. Focus on what made the difference.\n"
        )

    sections.append(
        "Analyze the evidence and write a diagnostic report in markdown. Include:\n"
        "- Summary of the root cause\n"
        "- Per-trial observations (what happened in each trial)\n"
        "- Failure patterns (if any)\n"
        "- Suggestions for fixing the issue\n"
    )

    return "\n".join(sections)


async def review_case(
    test_case: TestCase,
    case_dir: Path,
    trial_results: list[CaseResult],
    client: "AsyncOpenCodeClient",
    model: str | None = None,
) -> str:
    """Run a review agent to diagnose why a case failed.

    Analyzes all trials for a case, comparing successful and failed trials
    to identify patterns and root causes.

    Returns the review text (markdown).
    """
    from opencode_wrapper import RunConfig

    review_ws = _setup_review_workspace(case_dir, trial_results)
    try:
        prompt = _build_review_prompt(test_case, trial_results)
        cfg = RunConfig(model=model, permission=JUDGE_PERMISSION)
        result = await client.async_run(
            prompt, str(review_ws), run_cfg=cfg, timeout_s=300,
        )
        return _extract_text_from_result(result) or "(empty review response)"
    except Exception as e:
        log.error("Review error for case %s: %s", test_case.id, e)
        return f"Review error: {e}"
    finally:
        shutil.rmtree(review_ws, ignore_errors=True)
