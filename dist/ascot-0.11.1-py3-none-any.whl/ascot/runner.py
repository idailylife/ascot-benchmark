"""Benchmark runner: orchestrates OpenCode execution and grading."""

from __future__ import annotations

import asyncio
import json
import logging
import time
from dataclasses import replace
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from opencode_wrapper import (
    AsyncOpenCodeClient,
    OpenCodeError,
    OpenCodeProcessError,
    OpenCodeSession,
    OpenCodeTimeoutError,
    RunConfig,
    RunResult,
)
from opencode_wrapper.config import loads_jsonc

from . import __version__
from .graders import error_result, grade_case
from .models import BenchmarkReport, CaseResult, TestCase, TestSuite, aggregate_trials
from .store import RunStore
from .workspace import cleanup_workspace, preserve_workspace, setup_workspace

log = logging.getLogger(__name__)

# Default permissions: allow all tools, deny non-interactive / safety risks.
# Users can override individual keys in their suite's opencode.json.
DEFAULT_PERMISSION: dict[str, Any] = {
    "*": "allow",
    "question": "deny",
    "external_directory": "deny",
    "doom_loop": "deny",
}

# Auto-continue / completion-sentinel machinery. Every case runs as a session and is
# asked to signal completion; max_continues bounds how many "keep going" nudges follow.
# Everything ascot injects lives under `.ascot/` so it is excluded from preserved output.
INSTRUCTION_REL = ".ascot/completion.md"  # written by ascot, fed to the system prompt
SENTINEL_REL = ".ascot/complete"          # created by the agent to signal completion

COMPLETION_INSTRUCTION_TEXT = (
    "# Task completion protocol\n\n"
    "You are being evaluated on a task. Keep working until the task is FULLY "
    "complete.\n\n"
    "When — and only when — you are certain the task is finished, signal completion "
    "by creating an empty file at the exact path `.ascot/complete` in the current "
    "working directory (for example, run `touch .ascot/complete`, creating the "
    "`.ascot/` directory first if needed).\n\n"
    "Do NOT create this file until the task is genuinely done. If you stop before "
    "creating it, you will be prompted to continue.\n"
)

CONTINUE_PROMPT = (
    "You stopped before signaling completion. If the task is fully complete, create "
    "the `.ascot/complete` file now as instructed. Otherwise, continue working until "
    "it is done."
)

# One retry; the readiness failure is occasional/transient (concurrent server
# cold-starts racing their startup deadline), so a single restart — which runs
# after the initial burst — almost always starts cleanly.
_MAX_STARTUP_RETRIES = 1
_STARTUP_FAILURE_MARKERS = ("did not announce readiness", "did not become healthy")


def _is_startup_failure(e: Exception) -> bool:
    """True for opencode serve startup failures that are safe to retry.

    These are transient infra races (concurrent server cold-starts contending the
    readiness deadline), not failures of the suite under test. Match on the stderr
    marker rather than exit_code == -1 alone, since -1 is also produced by unrelated
    process kills that should not be retried.
    """
    return isinstance(e, OpenCodeProcessError) and any(
        m in (e.stderr or "") for m in _STARTUP_FAILURE_MARKERS
    )


def _merge_results(results: list[RunResult]) -> RunResult:
    """Combine per-turn RunResults from an auto-continue session into one.

    Stats (cost/turns/tokens) are summed across turns; final_text is the last
    non-empty turn's answer. The accumulated events.jsonl on disk remains the
    grader's evidence source, so the merged `.events` list is left empty.
    """
    merged = RunResult()
    if not results:
        return merged
    for r in results:
        merged.total_cost += r.total_cost
        merged.turns += r.turns
        tu, mu = r.token_usage, merged.token_usage
        mu.total += tu.total
        mu.input += tu.input
        mu.output += tu.output
        mu.reasoning += tu.reasoning
        mu.cache_read += tu.cache_read
        mu.cache_write += tu.cache_write
    merged.exit_code = results[-1].exit_code
    merged.session_id = results[0].session_id
    for r in reversed(results):
        if (r.final_text or "").strip():
            merged.final_text = r.final_text
            break
    return merged


# Event types kept out of events.jsonl as they stream (passed to the wrapper's
# `log_exclude_types`). The redundant token-by-token `message.part.delta` chunks
# never hit disk — the live file stays lean during a run instead of being
# rewritten only after the trial finishes. The final `message.part.updated`
# snapshot retains each part's full text; reasoning entries are kept for review.
_LOG_EXCLUDE_TYPES = frozenset({"message.part.delta"})


def _strip_delta_lines(events_path: Path) -> None:
    """Rewrite events.jsonl in place, dropping `message.part.delta` lines.

    Safety net for logs not produced with `_LOG_EXCLUDE_TYPES` (e.g. older runs).
    Session/server mode streams token-by-token `message.part.delta` chunks; the
    final `message.part.updated` snapshot already carries each part's full text,
    so the deltas are pure redundancy that can bloat the file 5-10x. Reasoning
    entries are deliberately kept here for `ascot review`. Malformed lines are
    preserved as-is.
    """
    if not events_path.exists():
        return
    kept: list[str] = []
    with open(events_path) as fin:
        for line in fin:
            stripped = line.strip()
            if not stripped:
                continue
            try:
                ev = json.loads(stripped)
            except json.JSONDecodeError:
                kept.append(line)
                continue
            if isinstance(ev, dict) and ev.get("type") == "message.part.delta":
                continue
            kept.append(line)
    with open(events_path, "w") as fout:
        fout.writelines(kept)


def _load_suite_permission(suite_dir: Path) -> dict[str, Any]:
    """Read user permission overrides from the suite's opencode.json."""
    for name in ("opencode.json", "opencode.jsonc"):
        cfg_path = suite_dir / name
        if cfg_path.exists():
            try:
                with open(cfg_path) as f:
                    data = loads_jsonc(f.read())
                if not isinstance(data, dict):
                    return {}
                return data.get("permission", {})
            except (ValueError, OSError):
                pass
    return {}


def build_permission(suite_dir: Path) -> dict[str, Any]:
    """Merge default permissions with user overrides from suite config.

    Default provides a safe base; user's suite opencode.json can override
    individual keys (e.g. deny bash for a read-only suite).
    """
    merged = dict(DEFAULT_PERMISSION)
    user_overrides = _load_suite_permission(suite_dir)
    merged.update(user_overrides)
    return merged


def build_report(
    suite_name: str,
    run_id: str,
    results: list[CaseResult],
    *,
    benchmark_model: str | None = None,
    grading_model: str | None = None,
) -> BenchmarkReport:
    total = len(results)
    total_score = sum(r.score for r in results)
    max_score = sum(r.max_score for r in results)
    total_turns = sum(r.turns for r in results)
    total_tokens = sum(r.token_usage.get("total", 0) for r in results)
    total_duration = sum(r.duration_s for r in results)
    total_cost = sum(r.total_cost for r in results)
    return BenchmarkReport(
        suite_name=suite_name,
        run_id=run_id,
        timestamp=datetime.now(timezone.utc).isoformat(),
        results=results,
        total=total,
        total_score=total_score,
        max_score=max_score,
        total_turns=total_turns,
        total_tokens=total_tokens,
        total_duration_s=total_duration,
        total_cost=total_cost,
        benchmark_model=benchmark_model,
        grading_model=grading_model,
        ascot_version=__version__,
    )


def _preserve_workspace_best_effort(ws: Path, dest: Path) -> float | None:
    """Preserve workspace output, logging and continuing on failure."""
    t_pres = time.monotonic()
    try:
        preserve_workspace(ws, dest)
    except Exception as e:
        log.warning("Could not preserve workspace %s to %s: %s", ws, dest, e)
        return None
    return round(time.monotonic() - t_pres, 3)


class BenchmarkRunner:
    """Runs a test suite against a suite configuration via OpenCode."""

    def __init__(
        self,
        suite_dir: Path,
        test_suite: TestSuite,
        output_dir: Path,
        *,
        concurrency: int = 2,
        model: str | None = None,
        binary: str = "opencode",
        testcases_dir: Path | None = None,
        venv: Path | None = None,
        trials: int = 1,
        inherit_user_config: bool = False,
        grading_model: str | None = None,
    ):
        self.suite_dir = suite_dir
        self.test_suite = test_suite
        self.output_dir = output_dir
        self.model = model or test_suite.default_model
        self.grading_model = grading_model or test_suite.grading_model or test_suite.default_model
        self.testcases_dir = testcases_dir
        self.concurrency = concurrency
        self.permission = build_permission(suite_dir)
        self.venv = venv
        self.trials = trials
        self.inherit_user_config = inherit_user_config

        self.client = AsyncOpenCodeClient(
            binary=binary,
            startup_concurrency=1,
            startup_delay_s=0.3,
            isolate_db=True,
        )
        self.sem = asyncio.Semaphore(concurrency)
        self.store = RunStore(output_dir)

    async def run_all(self) -> BenchmarkReport:
        """Run all test cases (with trials) and return a BenchmarkReport."""
        run_id, run_dir = self.store.next_run_dir()
        self.run_dir = run_dir

        self.store.save_meta(run_dir, {
            "suite_name": self.test_suite.name,
            "model": self.model,
            "benchmark_model": self.model,
            "grading_model": self.grading_model,
            "concurrency": self.concurrency,
            "trials": self.trials,
            "inherit_user_config": self.inherit_user_config,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_cases": len(self.test_suite.test_cases),
        })

        # Create one task per (case, trial) pair
        tasks = []
        for tc in self.test_suite.test_cases:
            for trial_num in range(1, self.trials + 1):
                tasks.append(
                    asyncio.create_task(self._run_guarded(tc, trial_num))
                )
        trial_results = await asyncio.gather(*tasks)

        # Group by case_id and aggregate
        from collections import defaultdict
        by_case: dict[str, list[CaseResult]] = defaultdict(list)
        for tr in trial_results:
            by_case[tr.case_id].append(tr)

        results = []
        for tc in self.test_suite.test_cases:
            trials = by_case[tc.id]
            agg = aggregate_trials(tc.id, trials)
            self.store.save_result(self.run_dir, tc.id, agg)
            results.append(agg)

        report = build_report(
            self.test_suite.name, run_id, results,
            benchmark_model=self.model,
            grading_model=self.grading_model,
        )
        report.num_trials = self.trials
        self.store.save_report(run_dir, report)
        return report

    async def _run_guarded(self, tc: TestCase, trial_num: int) -> CaseResult:
        async with self.sem:
            return await self._run_single(tc, trial_num)

    async def _run_single(self, tc: TestCase, trial_num: int) -> CaseResult:
        log.info("Running case: %s (trial %d/%d)", tc.id, trial_num, self.trials)
        ts_path = self._resolve_test_script(tc)
        self.store.save_eval(
            self.run_dir, tc.id, tc,
            test_script_path=ts_path,
            test_script_timeout_s=self.test_suite.default_test_script_timeout_s,
        )
        phases: dict[str, dict] = {}

        t_ws = time.monotonic()
        ws = setup_workspace(self.suite_dir, tc, self.testcases_dir)
        phases["workspace_setup"] = {"duration_s": round(time.monotonic() - t_ws, 3)}

        try:
            # If user provided a venv, inject it into PATH
            extra_env = None
            if self.venv:
                import os
                venv_bin = self.venv / "bin"
                if venv_bin.is_dir():
                    extra_env = {
                        "PATH": f"{venv_bin}:{os.environ.get('PATH', '')}",
                        "VIRTUAL_ENV": str(self.venv),
                    }

            cfg = RunConfig(
                model=self.model,
                agent=tc.agent,
                permission=self.permission,
                extra_env=extra_env,
                inherit_user_config=self.inherit_user_config,
            )
            trial_d = self.store.trial_dir(self.run_dir, tc.id, trial_num)
            events_path = trial_d / "events.jsonl"
            t0 = time.monotonic()
            result = None
            for attempt in range(_MAX_STARTUP_RETRIES + 1):
                try:
                    result = await self._run_session(tc, ws, cfg, events_path)
                    break
                except OpenCodeError as e:
                    if attempt < _MAX_STARTUP_RETRIES and _is_startup_failure(e):
                        log.warning(
                            "Case %s trial %d: opencode startup failed (%s); "
                            "retrying (%d/%d)",
                            tc.id, trial_num, e, attempt + 1, _MAX_STARTUP_RETRIES,
                        )
                        continue
                    raise
            duration = time.monotonic() - t0
            signaled_completion = (ws / SENTINEL_REL).exists()

            agent_stats = {
                "duration_s": round(duration, 3),
                "turns": result.turns,
                "cost": result.total_cost,
            }
            if hasattr(result, "token_usage"):
                tu = result.token_usage
                agent_stats["tokens"] = {
                    "total": tu.total, "input": tu.input,
                    "output": tu.output, "reasoning": tu.reasoning,
                    "cache_read": tu.cache_read, "cache_write": tu.cache_write,
                }
            phases["agent_run"] = agent_stats

            # Preserve workspace output
            t_pres = time.monotonic()
            ws_dest = trial_d / "workspace"
            preserve_workspace(ws, ws_dest)
            phases["workspace_preserve"] = {"duration_s": round(time.monotonic() - t_pres, 3)}

            # Grade
            t_grade = time.monotonic()
            case_result, grading_stats = await grade_case(
                tc, trial_d, result, duration, self.client,
                grading_model=self.grading_model,
                test_script_path=ts_path,
                test_script_timeout_s=self.test_suite.default_test_script_timeout_s,
                inherit_user_config=self.inherit_user_config,
            )
            grading_stats["duration_s"] = round(time.monotonic() - t_grade, 3)
            phases["grading"] = grading_stats

            case_result.signaled_completion = signaled_completion
            case_result.phases = phases
            self.store.save_trial_result(self.run_dir, tc.id, trial_num, case_result)

            log.info("Case %s trial %d: %d/%d (turns=%d, tokens=%d, %.1fs)",
                     tc.id, trial_num, case_result.score, case_result.max_score,
                     case_result.turns,
                     case_result.token_usage.get("total", 0), duration)
            return case_result

        except OpenCodeError as e:
            log.error("Case %s trial %d error: %s", tc.id, trial_num, e)
            trial_d = self.store.trial_dir(self.run_dir, tc.id, trial_num)
            if "workspace_preserve" not in phases:
                pres_s = _preserve_workspace_best_effort(ws, trial_d / "workspace")
                if pres_s is not None:
                    phases["workspace_preserve"] = {"duration_s": pres_s}
            cr = error_result(tc.id, e, tc)
            cr.phases = phases
            self.store.save_trial_result(self.run_dir, tc.id, trial_num, cr)
            return cr
        finally:
            cleanup_workspace(ws)

    async def _run_session(
        self, tc: TestCase, ws: Path, cfg: RunConfig, events_path: Path,
    ) -> RunResult:
        """Run a case as a multi-turn session with auto-continue.

        Injects a completion-protocol file into the agent's system prompt, then
        re-prompts the same session until the agent signals completion (creates
        SENTINEL_REL), the continue budget (tc.max_continues) is spent, or the
        total tc.timeout_s budget — spanning server startup and all turns — runs out.
        """
        instr_path = ws / INSTRUCTION_REL
        instr_path.parent.mkdir(parents=True, exist_ok=True)
        instr_path.write_text(COMPLETION_INSTRUCTION_TEXT)
        cfg = replace(cfg, instructions=[*(cfg.instructions or []), str(instr_path)])

        sentinel = ws / SENTINEL_REL
        deadline = time.monotonic() + tc.timeout_s
        results: list[RunResult] = []
        async with OpenCodeSession(
            self.client, str(ws), run_cfg=cfg, log_file=events_path,
            log_exclude_types=_LOG_EXCLUDE_TYPES, on_permission=None, on_question=None,
        ) as session:
            prompt = tc.prompt
            continues = 0
            while True:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    break
                try:
                    r = await session.send(prompt, timeout_s=remaining)
                except OpenCodeTimeoutError:
                    break  # partial events already flushed to log_file
                results.append(r)
                if sentinel.exists():
                    break
                if continues >= tc.max_continues:
                    break
                continues += 1
                prompt = CONTINUE_PROMPT
        _strip_delta_lines(events_path)
        return _merge_results(results)

    def _resolve_test_script(self, tc: TestCase) -> Path | None:
        """Resolve tc.test_script to an absolute path against testcases_dir."""
        if not tc.test_script:
            return None
        p = Path(tc.test_script)
        if not p.is_absolute() and self.testcases_dir:
            p = self.testcases_dir / p
        return p.resolve()
