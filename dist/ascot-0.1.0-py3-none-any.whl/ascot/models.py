"""Data models for Ascot benchmark framework."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Check:
    """A quick programmatic check (pre-condition before LLM judge)."""

    type: str  # "file_exists" | "file_contains" | "command_succeeds"
    config: dict[str, str] = field(default_factory=dict)


@dataclass
class TestCase:
    """A single benchmark test case."""

    id: str
    prompt: str
    checks: list[Check] = field(default_factory=list)
    expectations: str = ""
    description: str = ""
    workspace_files_from: str | None = None
    timeout_s: float = 120.0
    model: str | None = None
    agent: str | None = None
    tags: list[str] = field(default_factory=list)


@dataclass
class TestSuite:
    """A collection of test cases for a suite benchmark."""

    name: str
    test_cases: list[TestCase] = field(default_factory=list)
    description: str = ""
    default_timeout_s: float = 120.0
    default_model: str | None = None


@dataclass
class CheckResult:
    """Result of a single programmatic check."""

    type: str
    passed: bool
    message: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"type": self.type, "passed": self.passed, "message": self.message}


@dataclass
class JudgeResult:
    """Result from LLM judge evaluation."""

    passed: bool
    reasoning: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {"passed": self.passed, "reasoning": self.reasoning}


@dataclass
class CaseResult:
    """Aggregated result for one test case."""

    case_id: str
    passed: bool
    check_results: list[CheckResult] = field(default_factory=list)
    judge_result: JudgeResult | None = None
    final_text: str = ""
    exit_code: int | None = None
    token_usage: dict[str, int] = field(default_factory=dict)
    total_cost: float = 0.0
    turns: int = 0
    duration_s: float = 0.0
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "case_id": self.case_id,
            "passed": self.passed,
            "check_results": [cr.to_dict() for cr in self.check_results],
            "judge_result": self.judge_result.to_dict() if self.judge_result else None,
            "final_text": self.final_text,
            "exit_code": self.exit_code,
            "token_usage": self.token_usage,
            "total_cost": self.total_cost,
            "turns": self.turns,
            "duration_s": self.duration_s,
            "error": self.error,
        }
        return d


@dataclass
class BenchmarkReport:
    """Aggregated benchmark results."""

    suite_name: str
    run_id: str
    timestamp: str
    results: list[CaseResult] = field(default_factory=list)
    total: int = 0
    passed: int = 0
    pass_rate: float = 0.0
    # Core metrics (always shown)
    total_turns: int = 0
    total_tokens: int = 0
    total_duration_s: float = 0.0
    # Optional metric (hidden by default)
    total_cost: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "suite_name": self.suite_name,
            "run_id": self.run_id,
            "timestamp": self.timestamp,
            "results": [r.to_dict() for r in self.results],
            "total": self.total,
            "passed": self.passed,
            "pass_rate": self.pass_rate,
            "total_turns": self.total_turns,
            "total_tokens": self.total_tokens,
            "total_duration_s": self.total_duration_s,
            "total_cost": self.total_cost,
        }
