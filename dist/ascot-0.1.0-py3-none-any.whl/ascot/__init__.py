"""Ascot – benchmark framework for evaluating OpenCode suites."""

__version__ = "0.1.0"
