"""Report formatting: terminal and JSON output."""

from __future__ import annotations

import json
from typing import Any

from .models import BenchmarkReport, CaseResult


def format_terminal(report: BenchmarkReport, *, show_cost: bool = False) -> str:
    """Format a report for terminal display."""
    lines: list[str] = []
    w = 70

    lines.append("=" * w)
    lines.append(f" Ascot Benchmark: {report.suite_name}  |  {report.run_id}")
    lines.append("=" * w)

    # Header
    header = f" {'Case':<22} {'Status':<7} {'Checks':<8} {'Judge':<6} {'Turns':>5} {'Tokens':>8} {'Time':>7}"
    if show_cost:
        header += f" {'Cost':>8}"
    lines.append(header)
    lines.append("-" * w)

    # Per-case rows
    for r in report.results:
        status = "PASS" if r.passed else "FAIL"
        checks_total = len(r.check_results)
        checks_passed = sum(1 for c in r.check_results if c.passed)
        checks_str = f"{checks_passed}/{checks_total}" if checks_total else "-"

        if r.judge_result is not None:
            judge_str = "PASS" if r.judge_result.passed else "FAIL"
        elif r.error:
            judge_str = "ERR"
        else:
            judge_str = "-"

        tokens = r.token_usage.get("total", 0)
        row = f" {r.case_id:<22} {status:<7} {checks_str:<8} {judge_str:<6} {r.turns:>5} {tokens:>8,} {r.duration_s:>6.1f}s"
        if show_cost:
            row += f" ${r.total_cost:>7.4f}"
        lines.append(row)

    lines.append("-" * w)

    # Summary
    summary = (
        f" Total: {report.total} | Passed: {report.passed} | "
        f"Rate: {report.pass_rate:.1%}"
    )
    lines.append(summary)

    metrics = (
        f" Turns: {report.total_turns} | "
        f"Tokens: {report.total_tokens:,} | "
        f"Time: {report.total_duration_s:.1f}s"
    )
    if show_cost:
        metrics += f" | Cost: ${report.total_cost:.4f}"
    lines.append(metrics)

    # Show failed cases detail
    failed = [r for r in report.results if not r.passed]
    if failed:
        lines.append("")
        lines.append(" Failed cases:")
        for r in failed:
            lines.append(f"   {r.case_id}:")
            if r.error:
                lines.append(f"     Error: {r.error}")
            for cr in r.check_results:
                if not cr.passed:
                    lines.append(f"     [FAIL] {cr.type}: {cr.message}")
            if r.judge_result and not r.judge_result.passed:
                reasoning = r.judge_result.reasoning[:200]
                lines.append(f"     [FAIL] Judge: {reasoning}")

    lines.append("=" * w)
    return "\n".join(lines)


def format_json(report: BenchmarkReport) -> str:
    """Format report as JSON."""
    return json.dumps(report.to_dict(), indent=2, ensure_ascii=False)
