"""Two-phase grading: quick programmatic checks + LLM judge."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .models import CaseResult, Check, CheckResult, JudgeResult, TestCase

if TYPE_CHECKING:
    from opencode_wrapper import AsyncOpenCodeClient, RunConfig, RunResult


# ---------------------------------------------------------------------------
# Phase 1: Quick programmatic checks
# ---------------------------------------------------------------------------


def run_check(ws: Path, check: Check) -> CheckResult:
    """Execute a single programmatic check against the workspace."""
    handler = _CHECK_HANDLERS.get(check.type)
    if handler is None:
        return CheckResult(
            type=check.type,
            passed=False,
            message=f"Unknown check type: {check.type}",
        )
    return handler(ws, check.config)


def _check_file_exists(ws: Path, config: dict[str, str]) -> CheckResult:
    fp = ws / config["file"]
    ok = fp.exists()
    return CheckResult(
        type="file_exists",
        passed=ok,
        message=f"{'Found' if ok else 'Missing'}: {config['file']}",
    )


def _check_file_contains(ws: Path, config: dict[str, str]) -> CheckResult:
    fp = ws / config["file"]
    if not fp.exists():
        return CheckResult(
            type="file_contains",
            passed=False,
            message=f"File not found: {config['file']}",
        )
    try:
        content = fp.read_text(errors="replace")
    except Exception as e:
        return CheckResult(type="file_contains", passed=False, message=str(e))

    pattern = config.get("pattern", "")
    match = re.search(pattern, content)
    return CheckResult(
        type="file_contains",
        passed=bool(match),
        message=f"Pattern {'found' if match else 'not found'} in {config['file']}: {pattern}",
    )


def _check_command_succeeds(ws: Path, config: dict[str, str]) -> CheckResult:
    cmd = config["command"]
    try:
        result = subprocess.run(
            cmd, shell=True, cwd=ws, capture_output=True, text=True, timeout=30
        )
        ok = result.returncode == 0
        msg = f"exit={result.returncode}"
        if not ok and result.stderr.strip():
            msg += f" stderr={result.stderr.strip()[:200]}"
        return CheckResult(type="command_succeeds", passed=ok, message=msg)
    except subprocess.TimeoutExpired:
        return CheckResult(type="command_succeeds", passed=False, message="Command timed out (30s)")
    except Exception as e:
        return CheckResult(type="command_succeeds", passed=False, message=str(e))


_CHECK_HANDLERS = {
    "file_exists": _check_file_exists,
    "file_contains": _check_file_contains,
    "command_succeeds": _check_command_succeeds,
}


# ---------------------------------------------------------------------------
# Phase 2: LLM Judge (runs in isolated grader workspace)
# ---------------------------------------------------------------------------

# Judge gets full permissions inside its own workspace so it can write
# and run scripts to inspect binary files (xlsx, docx, images, etc.).
JUDGE_PERMISSION: dict[str, str] = {
    "*": "allow",
    "question": "deny",
    "external_directory": "deny",
    "doom_loop": "deny",
}


def _setup_judge_workspace(output_ws: Path) -> Path:
    """Create an isolated workspace for the judge with output files copied in.

    The judge can freely write helper scripts here without contaminating
    the original output.
    """
    judge_ws = Path(tempfile.mkdtemp(prefix="ascot_judge_"))
    # Copy output files into judge workspace under output/ subdirectory
    shutil.copytree(
        output_ws, judge_ws / "output",
        ignore=shutil.ignore_patterns(".opencode"),
    )
    return judge_ws


def _list_workspace_files(ws: Path, max_files: int = 50) -> str:
    """List files in workspace (excluding .opencode/) for the judge prompt."""
    files: list[str] = []
    for item in sorted(ws.rglob("*")):
        if ".opencode" in item.parts:
            continue
        if item.is_file():
            rel = item.relative_to(ws)
            size = item.stat().st_size
            files.append(f"  {rel}  ({size} bytes)")
            if len(files) >= max_files:
                files.append(f"  ... and more files (truncated at {max_files})")
                break
    return "\n".join(files) if files else "  (no files)"


async def llm_judge(
    ws: Path,
    test_case: TestCase,
    run_result: "RunResult",
    client: "AsyncOpenCodeClient",
) -> JudgeResult:
    """Run an OpenCode session in an isolated workspace to judge output."""
    from opencode_wrapper import RunConfig

    judge_ws = _setup_judge_workspace(ws)
    try:
        file_listing = _list_workspace_files(judge_ws / "output")
        final_text = _extract_text_from_result(run_result)

        # Write the agent's text output into judge workspace for reference
        if final_text:
            (judge_ws / "agent_output.txt").write_text(final_text)

        sections = [
            "You are a grading judge. Evaluate whether the agent's output "
            "meets the expected criteria.\n",
            f"## Expected Criteria\n{test_case.expectations}\n",
        ]

        if final_text:
            # Truncate very long output to avoid blowing context
            display_text = final_text if len(final_text) <= 4000 else final_text[:4000] + "\n... (truncated, full text in agent_output.txt)"
            sections.append(f"## Agent Text Output\n{display_text}\n")

        if file_listing.strip() and file_listing.strip() != "(no files)":
            sections.append(
                f"## Output Files (in output/ directory)\n{file_listing}\n"
            )

        sections.append(
            "Evaluate based on ALL available evidence: the agent's text output "
            "AND any files in output/. For binary files (xlsx, docx, etc.), "
            "write and run Python scripts to parse and verify their contents.\n\n"
            "Reply with ONLY a JSON object: "
            "{\"passed\": true/false, \"reasoning\": \"...\"}"
        )

        prompt = "\n".join(sections)
        cfg = RunConfig(permission=JUDGE_PERMISSION)
        result = await client.async_run(
            prompt, str(judge_ws), run_cfg=cfg, timeout_s=300,
        )
        text = _extract_text_from_result(result)
        return _parse_judge_response(text)
    except Exception as e:
        return JudgeResult(passed=False, reasoning=f"Judge error: {e}")
    finally:
        shutil.rmtree(judge_ws, ignore_errors=True)


def _parse_judge_response(text: str) -> JudgeResult:
    """Extract PASS/FAIL from judge LLM response."""
    # Try to find JSON with "passed" key anywhere in the text
    for match in re.finditer(r'\{[^{}]*"passed"\s*:\s*(true|false)[^{}]*\}', text, re.IGNORECASE):
        try:
            obj = json.loads(match.group())
            if "passed" in obj:
                return JudgeResult(
                    passed=bool(obj["passed"]),
                    reasoning=obj.get("reasoning", ""),
                )
        except json.JSONDecodeError:
            continue

    # Fallback: look for keywords but only in non-JSON text
    # Strip out JSON event lines to avoid false matches
    clean_lines = []
    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("{") and "sessionID" in stripped:
            continue  # skip raw event JSON
        clean_lines.append(stripped)
    clean = " ".join(clean_lines).lower()

    if '"passed": true' in clean or '"passed":true' in clean:
        return JudgeResult(passed=True, reasoning="\n".join(clean_lines)[:500])
    if '"passed": false' in clean or '"passed":false' in clean:
        return JudgeResult(passed=False, reasoning="\n".join(clean_lines)[:500])
    return JudgeResult(passed=False, reasoning=f"Could not parse judge response: {text[:500]}")


def _extract_text_from_result(run_result: "RunResult") -> str:
    """Extract human-readable text from a RunResult.

    OpenCode's --format json emits step_start/tool_use/step_finish events.
    The agent's text output may appear as:
    - Dedicated 'text' events (with part.text)
    - The last tool_use output before a step_finish (agent's final message)

    Falls back to run_result_fuzzy_text, but filters out raw JSON lines.
    """
    from opencode_wrapper import run_result_fuzzy_text

    # First try the standard extraction
    text = run_result.final_text.strip() if run_result.final_text else ""
    if text and not text.startswith('{"type":'):
        return text

    # Try fuzzy extraction
    fuzzy = run_result_fuzzy_text(run_result).strip()
    if fuzzy and not fuzzy.startswith('{"type":'):
        return fuzzy

    # Last resort: collect tool_use outputs that look like assistant text
    # (not structured tool results)
    pieces = []
    for ev in run_result.events:
        if ev.get("type") == "tool_use":
            part = ev.get("part", {})
            state = part.get("state", {})
            output = state.get("output", "")
            if isinstance(output, str) and output.strip():
                # Skip structured tool outputs (XML-like, very long)
                if not output.startswith("<") and len(output) < 2000:
                    pieces.append(output.strip())

    return "\n".join(pieces) if pieces else ""


# ---------------------------------------------------------------------------
# Combined grading
# ---------------------------------------------------------------------------


async def grade_case(
    test_case: TestCase,
    ws: Path,
    run_result: "RunResult",
    duration: float,
    client: "AsyncOpenCodeClient",
) -> CaseResult:
    """Grade a test case: quick checks first, then LLM judge if all pass."""
    # Phase 1: programmatic checks
    check_results = [run_check(ws, c) for c in test_case.checks]
    all_checks_passed = all(cr.passed for cr in check_results)

    # Phase 2: LLM judge (only if checks pass and expectations exist)
    judge_result = None
    if all_checks_passed and test_case.expectations.strip():
        judge_result = await llm_judge(ws, test_case, run_result, client)

    passed = all_checks_passed and (judge_result is None or judge_result.passed)

    token_dict = {}
    if hasattr(run_result, "token_usage"):
        tu = run_result.token_usage
        token_dict = {
            "total": tu.total,
            "input": tu.input,
            "output": tu.output,
        }

    return CaseResult(
        case_id=test_case.id,
        passed=passed,
        check_results=check_results,
        judge_result=judge_result,
        final_text=_extract_text_from_result(run_result),
        exit_code=run_result.exit_code,
        token_usage=token_dict,
        total_cost=run_result.total_cost,
        turns=run_result.turns,
        duration_s=duration,
    )


def error_result(case_id: str, error: Exception) -> CaseResult:
    """Create a failed CaseResult from an exception."""
    return CaseResult(
        case_id=case_id,
        passed=False,
        error=f"{type(error).__name__}: {error}",
    )
