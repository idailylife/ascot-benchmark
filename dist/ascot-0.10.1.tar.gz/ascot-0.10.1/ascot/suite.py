"""Suite directory resolution and YAML test case loading."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .models import Expectation, TestCase, TestSuite


def resolve_suite(suite_dir: str | Path) -> Path:
    """Resolve a suite directory to the path that should become .opencode/.

    Accepts either:
    - A directory containing a .opencode/ subdirectory (returns .opencode/)
    - A directory that IS the .opencode content (has opencode.json or skills/ etc.)
    """
    p = Path(suite_dir).resolve()
    if not p.is_dir():
        raise ValueError(f"Suite directory does not exist: {p}")
    if (p / ".opencode").is_dir():
        return p / ".opencode"
    if (p / "opencode.json").exists() or (p / "opencode.jsonc").exists():
        return p
    if (p / "skills").is_dir() or (p / "commands").is_dir():
        return p
    raise ValueError(
        f"Invalid suite directory: {p}\n"
        "Expected .opencode/ subdirectory, opencode.json, or skills/ directory."
    )


def _parse_test_case(raw: dict[str, Any], defaults: dict[str, Any]) -> TestCase:
    raw_expectations = raw.get("expectations", [])
    expectations = [
        Expectation(desc=e["desc"], score=e.get("score", 1))
        for e in raw_expectations
    ]
    return TestCase(
        id=raw["id"],
        prompt=raw["prompt"],
        expectations=expectations,
        description=raw.get("description", ""),
        workspace_files_from=raw.get("workspace_files_from", defaults.get("default_workspace_files_from")),
        timeout_s=raw.get("timeout_s", defaults.get("default_timeout_s", 600.0)),
        agent=raw.get("agent"),
        tags=raw.get("tags", []),
        test_script=raw.get("test_script"),
        max_continues=raw.get("max_continues", defaults.get("default_max_continues", 3)),
        append_grading_prompt=raw.get("append_grading_prompt"),
    )


def _load_yaml_file(path: Path) -> dict[str, Any]:
    with open(path) as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError(f"Expected YAML dict at top level, got {type(data).__name__}: {path}")
    return data


def load_test_suite(path: str | Path) -> TestSuite:
    """Load a TestSuite from a YAML file."""
    p = Path(path).resolve()

    if p.is_file():
        if p.suffix not in {".yaml", ".yml"}:
            raise ValueError(f"Test cases must be a YAML file (.yaml or .yml): {p}")
        data = _load_yaml_file(p)
        return _build_suite(data)

    if p.is_dir():
        raise ValueError(f"Test cases must be a YAML file, not a directory: {p}")

    raise ValueError(f"Test cases path does not exist: {p}")


def _build_suite(data: dict[str, Any]) -> TestSuite:
    defaults = {
        "default_timeout_s": data.get("default_timeout_s", 600.0),
        "default_model": data.get("default_model"),
        "default_workspace_files_from": data.get("default_workspace_files_from"),
        "default_max_continues": data.get("default_max_continues", 3),
    }
    cases = [_parse_test_case(dict(tc), defaults) for tc in data.get("test_cases", [])]
    return TestSuite(
        name=data.get("name", "unnamed"),
        test_cases=cases,
        description=data.get("description", ""),
        default_timeout_s=defaults["default_timeout_s"],
        default_model=defaults["default_model"],
        grading_model=data.get("grading_model"),
        default_workspace_files_from=defaults["default_workspace_files_from"],
        default_test_script_timeout_s=data.get("default_test_script_timeout_s", 60.0),
        default_max_continues=defaults["default_max_continues"],
    )
