# Ascot

Benchmark framework for evaluating [OpenCode](https://opencode.ai) suites.

A **suite** is a set of skills, MCP servers, instructions, and other OpenCode configurations that work together to solve a class of problems (e.g. document read/write, data processing). Ascot measures how well a suite performs by running test cases and grading the results.

## Install

```bash
pip install -e .
```

Requires `opencode` CLI on PATH. See [OpenCode docs](https://opencode.ai/docs/).

## Quick Start

```bash
python -m ascot run ./my-suite ./tests.yaml
```

This will:
1. Load the suite configuration from `./my-suite`
2. Parse test cases from `./tests.yaml`
3. For each test case, create an isolated workspace, copy the suite config in, run OpenCode
4. Grade results: quick programmatic checks first, then LLM judge for content evaluation
5. Print a report with pass/fail, turns, tokens, and duration

## Concepts

### Suite

A directory containing OpenCode configuration. Ascot accepts two layouts:

```
my-suite/                    # Layout A: directory IS the config
  opencode.json
  skills/
    my-skill/SKILL.md
  commands/
    my-cmd.md
```

```
my-project/                  # Layout B: has .opencode/ subdirectory
  .opencode/
    opencode.json
    skills/
      my-skill/SKILL.md
```

The suite's `opencode.json` does not need permission settings. Ascot injects sensible defaults (`"*": "allow"`, with `question`/`external_directory`/`doom_loop` denied). To override, add a `permission` block in the suite's `opencode.json` -- it will be merged on top of the defaults.

### Environment Setup

If your suite's skills or scripts depend on external packages (Python libraries, Node modules, system tools, etc.), set up the environment **before** running benchmarks.

**Option A: Activate environment in shell**

```bash
python -m venv .venv && source .venv/bin/activate
pip install -r my-suite/requirements.txt
ascot run ./my-suite ./tests.yaml
```

**Option B: Pass venv path via `--venv`**

```bash
python -m venv .venv
.venv/bin/pip install -r my-suite/requirements.txt
ascot run ./my-suite ./tests.yaml --venv .venv
```

Both approaches are equivalent. `--venv` injects the venv's `bin/` into `PATH` for each test case.

### Test Cases

YAML files defining what to test. A single file can contain multiple cases:

```yaml
name: doc-generation
description: "Document generation suite benchmark"
default_timeout_s: 180
default_model: anthropic/claude-sonnet-4-20250514

test_cases:
  - id: create-report
    prompt: |
      Create report.docx with title "Q1 Report" and a summary paragraph.
    checks:
      - type: file_exists
        file: report.docx
    expectations: |
      report.docx exists. Title is "Q1 Report".
      Contains a coherent summary paragraph.

  - id: summarize-pdf
    prompt: |
      Read input.pdf and provide a concise summary.
    workspace_files_from: fixtures/summarize-pdf
    expectations: |
      The summary accurately captures the key points of input.pdf.
      It is concise (under 500 words).

  - id: csv-to-xlsx
    prompt: "Convert data.csv to formatted output.xlsx"
    workspace_files:
      data.csv: |
        name,age,city
        Alice,30,NYC
        Bob,25,LA
    checks:
      - type: file_exists
        file: output.xlsx
    expectations: |
      output.xlsx contains all rows from data.csv.
      Headers are name, age, city.
    tags: [excel]
```

### Test Case Fields

| Field | Required | Description |
|---|---|---|
| `id` | yes | Unique identifier |
| `prompt` | yes | Prompt sent to OpenCode |
| `checks` | no | Quick programmatic checks (pre-conditions) |
| `expectations` | no | Natural language criteria for LLM judge |
| `workspace_files` | no | Text files to pre-populate in workspace (path -> content) |
| `workspace_files_from` | no | Directory of files to copy into workspace (supports binary) |
| `timeout_s` | no | Per-case timeout in seconds (default: 120) |
| `model` | no | Model override for this case |
| `agent` | no | Agent override for this case |
| `tags` | no | Tags for filtering (`--tag`) |

### Checks

Quick deterministic checks that run before the LLM judge. If any check fails, the case is immediately marked FAIL without invoking the judge.

```yaml
checks:
  # File exists
  - type: file_exists
    file: output.xlsx

  # File content matches regex
  - type: file_contains
    file: result.txt
    pattern: "total: \\d+"

  # Shell command exits 0
  - type: command_succeeds
    command: "python3 -c \"import openpyxl; openpyxl.load_workbook('output.xlsx')\""
```

### Grading

Ascot uses two-phase grading:

1. **Programmatic checks** -- fast, deterministic. Any failure skips the LLM judge.
2. **LLM judge** -- a separate OpenCode session evaluates the output against `expectations`. The judge runs in its own isolated workspace with full permissions, so it can write and run scripts to inspect binary files (xlsx, docx, etc.). It also sees the agent's text output, useful for tasks like "read a PDF and summarize it".

Grading is strictly outcome-based: if the agent did extensive work but didn't produce the expected result, it fails.

## CLI Reference

### `ascot run`

```bash
python -m ascot run <suite_dir> <testcases> [options]
```

| Flag | Default | Description |
|---|---|---|
| `-o, --output` | `./benchmark` | Output directory for results |
| `-m, --model` | suite default | Override model for all cases |
| `-c, --concurrency` | 2 | Max parallel cases |
| `-t, --timeout` | per-case | Override timeout for all cases (seconds) |
| `--binary` | `opencode` | Path to OpenCode binary |
| `--venv` | none | Path to pre-configured virtual environment |
| `--tag` | all | Only run cases matching tag (repeatable) |
| `--show-cost` | off | Show cost column in report |
| `-f, --format` | `terminal` | Output format: `terminal` or `json` |
| `-v, --verbose` | off | Debug logging (global flag, before subcommand) |

### `ascot grade`

Re-run LLM judge grading on a previous run (e.g. after updating expectations):

```bash
python -m ascot grade ./benchmark/run-001
```

### `ascot report`

Display report from an existing run:

```bash
python -m ascot report ./benchmark/run-001
python -m ascot report ./benchmark/run-001 -f json --show-cost
```

## Output Structure

Each run produces:

```
benchmark/
  run-001/
    meta.json              # Run metadata (suite, model, timestamp)
    report.json            # Aggregated results
    create-report/
      eval.json            # Test case definition
      result.json          # Pass/fail, grades, metrics
      events.jsonl         # Raw OpenCode event stream
      workspace/           # Preserved output files
        report.docx
    csv-to-xlsx/
      ...
```

## Report Example

```
======================================================================
 Ascot Benchmark: doc-generation  |  run-001
======================================================================
 Case                   Status  Checks   Judge  Turns   Tokens    Time
----------------------------------------------------------------------
 create-report          PASS    1/1      PASS       3    2,134    8.2s
 summarize-pdf          PASS    -        PASS       2    1,803    6.1s
 csv-to-xlsx            FAIL    1/1      FAIL       5    3,201   12.1s
----------------------------------------------------------------------
 Total: 3 | Passed: 2 | Rate: 66.7%
 Turns: 10 | Tokens: 7,138 | Time: 26.4s
======================================================================
```

## Permissions

Ascot injects default permissions via `OPENCODE_CONFIG_CONTENT`:

```json
{"*": "allow", "question": "deny", "external_directory": "deny", "doom_loop": "deny"}
```

- All tools allowed inside the workspace
- `question` denied (non-interactive)
- `external_directory` denied (sandbox to workspace)
- `doom_loop` denied (prevent infinite retries)

To override, add `permission` in your suite's `opencode.json`. User overrides are merged on top of defaults:

```json
{
  "permission": {
    "bash": "deny",
    "webfetch": "deny"
  }
}
```
